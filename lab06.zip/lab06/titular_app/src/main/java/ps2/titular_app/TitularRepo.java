package ps2.titular_app;

import org.springframework.data.repository.CrudRepository;

public interface TitularRepo extends CrudRepository<Titular, Long> {
    
}
